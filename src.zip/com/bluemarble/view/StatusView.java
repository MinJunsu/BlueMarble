package com.bluemarble.view;

import com.bluemarble.model.Country;

import javax.swing.*;

public class StatusView extends JDialog
{
    public StatusView(JFrame frame, String title, int country)
    {
        super(frame, title);
        setBounds(300, 400, 600, 400);
        JLabel label = new JLabel(String.valueOf(country));
        add(label);
    }
}
