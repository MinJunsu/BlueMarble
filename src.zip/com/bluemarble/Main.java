package com.bluemarble;

import com.bluemarble.controller.PlayGame;
import com.bluemarble.model.*;
import com.bluemarble.view.MainView;

public class Main
{
    public static void main(String[] args)
    {
        Dice dice = new Dice();
        MainView view = new MainView(dice);
        PlayGame game = new PlayGame(4, dice, view);
        game.isClicked();
    }
}
