package com.bluemarble.model;

public class Others extends Board
{
    private String name;
    private int otherType;

    public Others(String name, int otherType)
    {
        super(false);
        this.name = name;
        this.otherType = otherType;
    }

    @Override
    public String getName()
    {
        return name;
    }

    @Override
    public int getOtherType()
    {
        return otherType;
    }

    @Override
    public void travel()
    {

    }

    @Override
    public boolean isolated()
    {
        return false;
    }

    @Override
    public void donation()
    {

    }

    @Override
    public void getPaid()
    {

    }

    // Country 전용 메서드

    @Override
    public int getTollFee() { return 0; }

    @Override
    public int getCountryPrice() { return 0; }

    @Override
    public void buyConstructor(int choices, int count) { }

    @Override
    public void buyCountry(Player player) { }

    @Override
    public int getVillaPrice() { return 0; }

    @Override
    public int getBuildingPrice() { return 0; }

    @Override
    public int getHotelPrice() { return 0; }
}
