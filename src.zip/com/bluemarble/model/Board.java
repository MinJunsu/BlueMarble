package com.bluemarble.model;

public abstract class Board
{
    private boolean type;

    public Board(boolean type)
    {
        this.type = type;
    }

    public boolean getType()
    {
        return this.type;
    }

    public abstract String getName();

    public abstract void buyConstructor(int choices, int count);

    public abstract void buyCountry(Player player);

    public abstract int getTollFee();

    public abstract int getCountryPrice();

    public abstract int getOtherType();

    public abstract int getVillaPrice();

    public abstract int getBuildingPrice();

    public abstract int getHotelPrice();

    public abstract void travel();

    public abstract boolean isolated();

    public abstract void donation();

    public abstract void getPaid();
}
