package com.bluemarble.controller;

import com.bluemarble.model.*;
import com.bluemarble.view.GameBoardView;
import com.bluemarble.view.MainView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PlayGame
{
    private int playerCount;
    private Board[] boards;
    private Player[] players;
    private Dice dice;
    private MainView view;
    private GameBoardView gameBoardView;
    private JButton diceButton, turnOverButton;
    private Bank bank;
    private int doubleCount, turn;
    private int firstNumber, secondNumber;

    public PlayGame(int playerCount, Dice dice, MainView view)
    {
        boards = GameBoard.getBoards();
        turn = 0;
        this.playerCount = playerCount;
        this.dice = dice;
        this.view = view;
        this.gameBoardView = view.getGameBoardView();
        this.diceButton = gameBoardView.getDiceButton();
        this.turnOverButton = gameBoardView.getTurnOverButton();
    }

    private void play()
    {


    }

    public void isClicked()
    {
        diceButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                dice.throwDice();
                firstNumber = dice.getFirstDice();
                secondNumber = dice.getSecondDice();
                gameBoardView.setDice(firstNumber, secondNumber);
                if(firstNumber != secondNumber)
                {
                    turnOverButton.setEnabled(true);
                    diceButton.setEnabled(false);
                }
                gameBoardView.setDoubleLabelText(++doubleCount);
                if(doubleCount == 3)
                {
                    // 무인도 보내기.
                }
                play();
            }
        });

        turnOverButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                gameBoardView.setTurnLabelText((turn ++ % 4) + 1);
                turnOverButton.setEnabled(false);
                diceButton.setEnabled(true);
                doubleCount = 0;
            }
        });
    }
}
